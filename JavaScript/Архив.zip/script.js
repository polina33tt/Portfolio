const projectTitle = "Прогноз погоды";
const projectDescription = "Веб-приложение для отображения текущей погоды";
const projectTheme = "Порода";
const projectAuthor = "Студент группы Вд-4-23";
const projectYear = 2026;
const isFinished = false;
const projectVersion = "1.0"; 


const titleElement = document.querySelector("#projectTitle");
const descriptionElement = document.querySelector("#projectDescription");
const themeElement = document.querySelector("#projectTheme");
const authorElement = document.querySelector("#projectAuthor");
const yearElement = document.querySelector("#projectYear");
const statusElement = document.querySelector("#projectStatus");
const versionElement = document.createElement("li"); 


const listElement = document.querySelector("ul");
listElement.appendChild(versionElement);
versionElement.id = "projectVersion"; 

titleElement.textContent = projectTitle;
descriptionElement.textContent = projectDescription;
themeElement.textContent = projectTheme;
authorElement.textContent = projectAuthor;
yearElement.textContent = projectYear;

if (projectVersion === "1.0") {
    versionElement.textContent = "Первая версия"; 
} else {
    versionElement.textContent = projectVersion;
}

if (isFinished === false) {
    statusElement.textContent = "Проект находится в разработке";
} else {
    statusElement.textContent = "Проект завершён";
}

console.log(projectTitle);
console.log(projectDescription);
console.log(projectTheme);
console.log(projectAuthor);
console.log(projectYear);
console.log(isFinished);
console.log(projectVersion); 