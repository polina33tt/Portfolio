const projectTitle = "Прогноз погоды";
const projectDescription = "Веб-приложение для отображения текущей погоды";
const projectTheme = "Порода";
const projectAuthor = "Студент группы Вд-4-23";
const projectYear = 2026;
const projectVersion = "2"; 
const isFinished = true;
const isActive = false;
const hasError = true;

console.log(projectTitle);
console.log(projectDescription);
console.log(projectTheme);
console.log(projectAuthor);
console.log(projectYear);
console.log(isFinished);
console.log(projectVersion); 

const titleElement = document.querySelector("#projectTitle");
const descriptionElement = document.querySelector("#projectDescription");
const themeElement = document.querySelector("#projectTheme");
const authorElement = document.querySelector("#projectAuthor");
const yearElement = document.querySelector("#projectYear");
const statusElement = document.querySelector("#projectStatus");
const versionElement = document.querySelector("#versionElement");
const detailsElement = document.querySelector("#projectDetails"); 
const infoElement = document.querySelector("#infoElement");
const warningElement = document.querySelector("#warningMessage");

function renderProjectInfo() {
    titleElement.textContent = projectTitle;
    descriptionElement.textContent = projectDescription;
    themeElement.textContent = projectTheme;
    authorElement.textContent = projectAuthor;
    yearElement.textContent = projectYear;
    
    
    if (projectVersion === "1.0") {
        versionElement.textContent = "Первая версия"; 
    } else {
        versionElement.textContent = projectVersion;
    }
}

function getProjectStatusText(hasError, isActive, isFinished) {
    if (hasError === true) {
        return "Ошибка в работе проекта";
    } else if (isActive === true && isFinished === true) {
        return "Некорректное состояние проекта";
    } else if (isFinished === true) {
        return "Проект завершён";
    } else if (isActive === true) {
        return "Проект активен";
    } else {
        return "Проект находится в разработке";
    }
}

function getProjectVersionText(version) {
    if (version < 1) {
        return "Версия проекта: тестовая";
    } else if (version < 1.5) {
        return "Версия проекта: базовая";
    } else if (version < 2) {
        return "Версия проекта: улучшенная";
    } else {
        return "Версия проекта: продвинутая";
    }
}

function updateInterfaceVisibility() {
    if (hasError === true) {
        detailsElement.style.display = "none";
        warningElement.style.display = "block";
    } else {
        detailsElement.style.display = "block";
        warningElement.style.display = "none";
    }
}

function updateProject() {
    renderProjectInfo();

statusElement.textContent = getProjectStatusText(
    hasError,
    isActive,
    isFinished
);

infoElement.textContent = getProjectVersionText(projectVersion);

updateInterfaceVisibility();
}
updateProject();