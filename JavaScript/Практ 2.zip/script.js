const projectTitle = "Прогноз погоды";
const projectDescription = "Веб-приложение для отображения текущей погоды";
const projectTheme = "Порода";
const projectAuthor = "Студент группы Вд-4-23";
const projectYear = 2026;
const projectVersion = "1.2"; 
const isFinished = true;
const isActive = true;
const hasError = true;


console.log(projectTitle);
console.log(projectDescription);
console.log(projectTheme);
console.log(projectAuthor);
console.log(projectYear);
console.log(isFinished);
console.log(projectVersion); 


const titleElement = document.querySelector("#projectTitle");
const descriptionElement = document.querySelector("#projectDescription");
const themeElement = document.querySelector("#projectTheme");
const authorElement = document.querySelector("#projectAuthor");
const yearElement = document.querySelector("#projectYear");
const statusElement = document.querySelector("#projectStatus");
const versionElement = document.querySelector("#versionElement");
const detailsElement = document.querySelector("#projectDetails"); 
const infoElement = document.querySelector("#infoElement");
const warningElement = document.querySelector("#warningMessage");


titleElement.textContent = projectTitle;
descriptionElement.textContent = projectDescription;
themeElement.textContent = projectTheme;
authorElement.textContent = projectAuthor;
yearElement.textContent = projectYear;

if (projectVersion === "1.0") {
    versionElement.textContent = "Первая версия"; 
} else {
    versionElement.textContent = projectVersion;
}


if (hasError === true) {

    statusElement.textContent = "Ошибка в работе проекта";

} else if (isActive === true && isFinished === true) {

    statusElement.textContent = "Некорректное состояние проекта";

} else if (isActive === true && isFinished === false) {

    statusElement.textContent = "Проект активен";

} else if (isActive === false && isFinished === true) {

    statusElement.textContent = "Проект завершён";

} else if (isActive === false && isFinished === false) {

    statusElement.textContent = "Проект находится в разработке";

} else {

    statusElement.textContent = "Некорректное состояние проекта";

}



if (projectVersion < 1) {
    versionElement.textContent = "Тестовая версия";
    console.log("Проект находится на тестовой версии");

} else if (projectVersion >= 1 && projectVersion < 1.5) {
    versionElement.textContent = "Базовая версия";
    console.log("Проект работает в базовой версии");

} else if (projectVersion >= 1.5 && projectVersion < 2) {
    versionElement.textContent = "Улучшенная версия";
    console.log("Проект обновлён до улучшенной версии");

} else {
    versionElement.textContent = "Продвинутая версия";
    console.log("Проект достиг продвинутой версии");
}


if (projectVersion < 1) {
    infoElement.textContent = "Статус версии: тестовая";
} else if (projectVersion >= 1 && projectVersion < 1.5) {
    infoElement.textContent = "Статус версии: базовая";
} else if (projectVersion >= 1.5 && projectVersion < 2) {
    infoElement.textContent = "Статус версии: улучшенная";
} else {
    infoElement.textContent = "Статус версии: продвинутая";
}




if (projectVersion < 1) {
    infoElement.textContent = "Версия проекта: тестовая";
} else {
    infoElement.textContent = "Версия проекта: стабильная";
}



if (hasError === true) {
    warningElement.style.display = "block";
    console.log("ох у тебя есть ошибка");
} else {
    warningElement.style.display = "none";
    console.log("хехе ошибок нет");
}